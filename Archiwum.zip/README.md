# clueSerialServer
This repository holds clue. lamp configuration webpage.
It allows user to select animation mode:
* full color
* palette
* palette test mode (showing currently set palette)

for palette user can select up to 10 colors that will create the animation.

# running
clone repository and use command http-server when inside